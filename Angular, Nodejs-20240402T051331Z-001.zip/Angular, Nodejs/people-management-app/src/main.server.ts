// main.server.ts

import 'zone.js/dist/zone-node';
import * as express from 'express';
import { join } from 'path';
import { readFileSync } from 'fs';
import { enableProdMode } from '@angular/core';
import { ngExpressEngine } from '@nguniversal/express-engine';

// Enable production mode
enableProdMode();

// Express server
const app = express();

// Define the port
const PORT = process.env.PORT || 4000;

// Define the Angular app directory
const DIST_FOLDER = join(process.cwd(), 'dist', 'your-angular-app');

// Serve static files from the Angular app directory
app.use(express.static(DIST_FOLDER));

// Set up Angular Universal server-side rendering
app.engine('html', ngExpressEngine({
  bootstrap: AppServerModule,
}));

app.set('view engine', 'html');
app.set('views', join(DIST_FOLDER, 'browser'));

// Serve Angular Universal application for all other routes
app.get('*', (req, res) => {
  res.render('index', { req });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
