// main.ts

import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

// Enable production mode if production environment
if (environment.production) {
  enableProdMode();
}

// Bootstrap the AppModule to start the application
platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
