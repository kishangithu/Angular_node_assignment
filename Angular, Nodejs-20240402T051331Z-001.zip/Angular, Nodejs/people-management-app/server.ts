import 'zone.js/dist/zone-node';
import * as express from 'express';
import { join } from 'path';
import { readFileSync } from 'fs';
import { enableProdMode } from '@angular/core';

// Enable production mode
enableProdMode();

// Express server
const app = express();

// Define the port
const PORT = process.env.PORT || 4000;

// Define the Angular app directory
const DIST_FOLDER = join(process.cwd(), 'dist', 'your-angular-app');

// Serve static files from the Angular app directory
app.use(express.static(DIST_FOLDER));

// Handle requests for static files (e.g., index.html)
app.get('*', (req, res) => {
  const indexHtml = readFileSync(join(DIST_FOLDER, 'index.html'), 'utf8');
  res.send(indexHtml);
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
