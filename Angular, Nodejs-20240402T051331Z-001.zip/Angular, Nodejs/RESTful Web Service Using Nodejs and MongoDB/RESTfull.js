const express = require('express');
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/peopleDB', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => console.log('Connected to MongoDB'));

const personSchema = new mongoose.Schema({
    name: String,
    age: Number,
    gender: String,
    mobileNumber: String
});

const Person = mongoose.model('Person', personSchema);
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

app.get('/person', async (req, res) => {
    try {
        const people = await Person.find();
        res.json(people);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.post('/person', async (req, res) => {
    const person = new Person({
        name: req.body.name,
        age: req.body.age,
        gender: req.body.gender,
        mobileNumber: req.body.mobileNumber
    });
    try {
        const newPerson = await person.save();
        res.status(201).json(newPerson);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

app.put('/person/:id', async (req, res) => {
    try {
        const updatedPerson = await Person.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedPerson);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

app.delete('/person/:id', async (req, res) => {
    try {
        const deletedPerson = await Person.findOneAndDelete({ _id: req.params.id });
        if (!deletedPerson) {
            return res.status(404).json({ message: 'Person not found' });
        }
        res.json({ message: 'Person deleted', deletedPerson });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.listen(port, () => {
    console.log(Server is running on port ${port});
});